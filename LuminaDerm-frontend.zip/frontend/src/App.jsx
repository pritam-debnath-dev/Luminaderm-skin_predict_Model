import { useMemo, useState } from 'react'
import { predictImage } from './lib/api.js'

const QUESTIONS = [
  ['noticed', 'When did you first notice it?', ['Today','A few days ago','1–2 weeks ago','More than a month ago','Not sure']],
  ['itch', 'Is it itchy?', ['Not at all','Mildly','Moderately','Severely','Not sure']],
  ['pain', 'Does it burn or hurt when touched?', ['No','Mildly','Moderately','Severely','Not sure']],
  ['size', 'Has it changed in size?', ['No change','Getting smaller','Getting larger','Not sure']],
  ['fluid', 'Is there fluid, pus, bleeding, or crusting?', ['None','Fluid','Pus','Bleeding','Crusting','Not sure']],
  ['location', 'Where is it located?', ['Face','Scalp','Chest/back','Arms','Legs','Hands/feet','Other']],
  ['moreSpots', 'Are there more spots or areas like this?', ['Yes','No','Not sure']],
  ['previous', 'Have you had a similar problem before?', ['Yes','No','Not sure']],
].map(([key,title,options]) => ({key,title,options}))

function normalizePrediction(data) {
  const top = Array.isArray(data?.top_conditions) ? data.top_conditions : []
  return {
    condition: data?.condition || data?.prediction || data?.class_name || data?.label || top[0]?.condition || 'Unknown condition',
    score: data?.confidence ?? data?.score ?? data?.probability ?? top[0]?.score ?? null,
    topConditions: top,
  }
}

function formatScore(score) {
  if (score === null || score === undefined || Number.isNaN(Number(score))) return 'Not available'
  const value = Number(score)
  return `${value <= 1 ? (value * 100).toFixed(1) : value.toFixed(1)}%`
}

export default function App() {
  const [step,setStep]=useState('upload')
  const [file,setFile]=useState(null)
  const [preview,setPreview]=useState('')
  const [questionIndex,setQuestionIndex]=useState(0)
  const [answers,setAnswers]=useState({})
  const [prediction,setPrediction]=useState(null)
  const [error,setError]=useState('')
  const [loading,setLoading]=useState(false)

  const question=QUESTIONS[questionIndex]
  const progress=((questionIndex+1)/QUESTIONS.length)*100
  const answerSummary=useMemo(()=>QUESTIONS.filter(q=>answers[q.key]).map(q=>({label:q.title,value:answers[q.key]})),[answers])

  function handleFileChange(e){
    const selected=e.target.files?.[0]
    if(!selected)return
    setError(''); setFile(selected); setPreview(URL.createObjectURL(selected))
  }

  async function analyzeImage(){
    if(!file)return
    setError(''); setLoading(true)
    try{
      const result=await predictImage(file)
      setPrediction(normalizePrediction(result))
      setStep('questions')
    }catch(err){ setError(err.message || 'Unable to analyze the image.') }
    finally{ setLoading(false) }
  }

  function chooseAnswer(value){ setAnswers(current=>({...current,[question.key]:value})) }
  function nextQuestion(){
    if(!answers[question.key])return
    if(questionIndex<QUESTIONS.length-1)setQuestionIndex(i=>i+1)
    else setStep('results')
  }
  function previousQuestion(){
    if(questionIndex>0)setQuestionIndex(i=>i-1)
    else setStep('upload')
  }
  function startOver(){
    setStep('upload'); setFile(null); setPreview(''); setQuestionIndex(0)
    setAnswers({}); setPrediction(null); setError('')
  }

  return <main className="page-shell">
    <header className="topbar">
      <div className="brand-mark">✦</div>
      <div><div className="brand-name">LuminaDerm</div><div className="brand-subtitle">AI-assisted skin assessment</div></div>
    </header>

    <section className="hero">
      <div className="eyebrow">EXPERIMENTAL AI SKIN-ASSESSMENT TOOL</div>
      <h1>Understand your skin with a little more context.</h1>
      <p>Upload a clear image, then answer a few short questions. LuminaDerm uses the image model for its prediction and keeps your answers as separate user-reported context.</p>
      <div className="notice">Not a medical diagnosis. Model scores are experimental and not calibrated probabilities.</div>
    </section>

    <section className="card">
      {step==='upload' && <>
        <div className="step-label">STEP 01 — UPLOAD</div>
        <h2>Upload a skin image</h2>
        <p className="muted">Use a clear, well-lit photo. Avoid including unnecessary personal information in the image.</p>
        <label className="upload-box" htmlFor="skin-image">
          {preview ? <img className="preview" src={preview} alt="Selected skin image preview"/> :
          <><div className="upload-icon">↑</div><strong>Choose an image</strong><span>JPG, PNG or WEBP</span></>}
          <input id="skin-image" type="file" accept="image/*" onChange={handleFileChange}/>
        </label>
        {file && <div className="file-name">Selected: {file.name}</div>}
        {error && <div className="error">{error}</div>}
        <button className="primary" disabled={!file || loading} onClick={analyzeImage}>{loading?'Analyzing image…':'Analyze image'}</button>
      </>}

      {step==='questions' && <>
        <div className="question-header">
          <div className="step-label">STEP 02 — SYMPTOMS & HISTORY</div>
          <span>Question {questionIndex+1} of {QUESTIONS.length}</span>
        </div>
        <div className="progress-track"><div className="progress-value" style={{width:`${progress}%`}}/></div>
        {preview && <img className="thumb" src={preview} alt="Uploaded skin image"/>}
        <h2>{question.title}</h2>
        <div className="options">{question.options.map(option=>
          <button key={option} className={`option ${answers[question.key]===option?'selected':''}`} onClick={()=>chooseAnswer(option)}>{option}</button>
        )}</div>
        <div className="button-row">
          <button className="secondary" onClick={previousQuestion}>Back</button>
          <button className="primary" disabled={!answers[question.key]} onClick={nextQuestion}>{questionIndex===QUESTIONS.length-1?'View results':'Next'}</button>
        </div>
      </>}

      {step==='results' && prediction && <>
        <div className="step-label">RESULTS</div>
        <h2>Your LuminaDerm assessment</h2>
        <p className="muted">The image prediction and your questionnaire answers are shown separately.</p>
        <div className="result-grid">
          <article className="result-panel highlight">
            <span className="panel-label">IMAGE AI RESULT</span>
            <h3>{prediction.condition}</h3>
            <div className="score">{formatScore(prediction.score)}</div>
            <p>Experimental model output from the uploaded image. This is not a calibrated medical probability or diagnosis.</p>
          </article>
          <article className="result-panel">
            <span className="panel-label">USER-REPORTED SYMPTOMS</span>
            <div className="answer-list">{answerSummary.map(item=>
              <div className="answer-row" key={item.label}><span>{item.label}</span><strong>{item.value}</strong></div>
            )}</div>
          </article>
        </div>

        {prediction.topConditions.length>1 && <div className="top-matches">
          <span className="panel-label">OTHER MODEL MATCHES</span>
          {prediction.topConditions.slice(0,5).map(item=>
            <div className="match-row" key={item.condition}><span>{item.condition}</span><strong>{formatScore(item.score)}</strong></div>
          )}
        </div>}

        <div className="interpretation"><strong>How to read this</strong><p>Your questionnaire answers provide context for you to review alongside the image result. With the current image-only endpoint, those answers are not sent into the prediction model.</p></div>
        <div className="medical-note">If a skin change is rapidly worsening, very painful, associated with significant swelling, fever, breathing difficulty, or other concerning symptoms, seek appropriate medical care rather than relying on this tool.</div>
        <button className="secondary full" onClick={startOver}>Analyze another image</button>
      </>}

    </section>
    <footer>LuminaDerm is an experimental informational project. It does not replace a qualified healthcare professional.</footer>
  </main>
}
