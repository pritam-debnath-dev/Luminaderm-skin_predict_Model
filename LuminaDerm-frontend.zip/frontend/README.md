# LuminaDerm Frontend

React/Vite frontend for LuminaDerm, an experimental AI-assisted skin assessment project.

## Flow
1. Upload a skin image.
2. Send it to the existing FastAPI `/predict` endpoint.
3. Show the image-model result.
4. Ask eight short symptom/history questions.
5. Show the model result separately from user-reported context.

The current `/predict` endpoint is image-only, so questionnaire answers are not sent into the prediction model.

## Backend
Default: `https://skin-ai-backend-1myc.onrender.com`

Override with `.env`:
```env
VITE_API_BASE_URL=https://your-backend.example.com
```

## Run
```bash
npm install
npm run dev
```

## Build
```bash
npm run build
```

This frontend is intended to live in the main GitHub repository under `frontend/`.

Do not commit private API keys, passwords, tokens, or secret credentials.
